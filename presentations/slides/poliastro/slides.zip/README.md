# poliastro

Press the button to launch a cloud Jupyter notebook with the talk.

[![Binder](http://mybinder.org/badge.svg)](http://mybinder.org/v2/gh/astrojuanlu/scipy-us-2022-poliastro-talk/main?filepath=Talk.ipynb)
